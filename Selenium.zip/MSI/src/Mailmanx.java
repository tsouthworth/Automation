import java.util.logging.Level;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeMultipart;

import java.util.*;

/**
*
* @author user
*/
public class Mailmanx {

// new MailWithPasswordAuthentication().run();

String body,subject;
public void mail_alist(ArrayList lines,String asubject)
{
//String user, pass, subject, body;

subject="hello";
body="hello";

for(int i=0; i<lines.size(); i++) {
body+=((String)lines.get(i))+"\n";
}
try {
Sendmail(body, subject);
} catch (MessagingException ex) {
Logger.getLogger(Mailmanx.class.getName()).log(Level.SEVERE, null, ex);
}
}

public void Sendmail(String body, String subject) throws MessagingException ////this is used to send the emails
{

Message message = new MimeMessage(getSession());

////test bit
// message.addRecipient(RecipientType.TO, new InternetAddress("TO_mail@corporate.com"));///change to dist list
// message.addFrom(new InternetAddress[] { new InternetAddress("from_mail@corporate.com") });
///end test bit

message.addRecipient(RecipientType.TO, new InternetAddress("qa@meclabs.com"));///change to dist list
message.addFrom(new InternetAddress[] { new InternetAddress("qa@meclabs.com") });

message.setSubject(subject);
message.setContent(body, "text/plain");

Multipart multiPart = new MimeMultipart();  

MimeBodyPart rarAttachment = new MimeBodyPart();  
FileDataSource rarFile = new FileDataSource("C:/out.html");  
rarAttachment.setDataHandler(new DataHandler(rarFile));  
rarAttachment.setFileName(rarFile.getName());  
multiPart.addBodyPart(rarAttachment);  
message.setContent(multiPart);  

Transport.send(message);
}

private Session getSession() {
Authenticator authenticator = new Authenticator();

Properties properties = new Properties();
properties.setProperty("mail.smtp.submitter", authenticator.getPasswordAuthentication().getUserName());
properties.setProperty("mail.smtp.auth", "true");

properties.setProperty("mail.smtp.host", "smtp.ihostexchange.net");
properties.setProperty("mail.smtp.port", "587");

return Session.getInstance(properties, authenticator);
}

private class Authenticator extends javax.mail.Authenticator {
private PasswordAuthentication authentication;

public Authenticator() {
String username = "thomas.southworth@meclabs.com";
String password = "201$tHw30";
authentication = new PasswordAuthentication(username, password);
}

protected PasswordAuthentication getPasswordAuthentication() {
return authentication;
}
}
}
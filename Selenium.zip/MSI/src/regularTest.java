
import org.junit.AfterClass;
import org.openqa.selenium.server.SeleniumServer;
import org.testng.annotations.*;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import javax.mail.MessagingException;

import jxl.*;
import com.thoughtworks.selenium.*;

public class regularTest extends SeleneseTestCase {
	private Object[][] retObjArr;
	private SeleniumServer seleniumserver;
	
@BeforeClass
    public void setUp() throws Exception {
	
		retObjArr = getTableArray("MSI.xls", "Testing");
//test
		seleniumserver = new SeleniumServer();
		seleniumserver.boot();
		seleniumserver.start();
		setUp(String.valueOf(retObjArr[0][0]), "*chrome"); 
	}

@Test 
    public void testNYTDataProviderExample() throws Exception { 
		
		//Create error variable and log path
		String logPath = "c:\\out.html";
		StringBuffer  sb = new StringBuffer();
		sb.append("<!DOCTYPE html>\n<html>\n\t<head>\n\t\t<title>QA Log</title>\n\t\t<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js\" type=\"text/javascript\"></script>\n\t\t<script type=\"text/javascript\">\n\t\t\tfunction toggle(num){ \n\t\t\t\t$('#error' + num).slideToggle('fast', function(){});\n\t\t\t}\n\t\t</script>\n\t\t<style type=\"text/css\">\n\t\t\tdiv{font-size:18px; margin-top:20px}\n\t\t\t.sub{margin:5px 0 5px 25px; color:#494949; font-size:14px}\n\t\t\tspan{color:#DD4B02; font-weight:bold}\n\t\t\t.select{color:#34357F}\n\t\t\t.noText{color:#971204}\n\t\t\t.radio{color:#45B3DB}\n\t\t</style>\n\t</head>\n<body>\n");
		
	
		//Start a robot up incase we need him
		Robot r = new Robot();
        
		String url = null;
		
		//Loop though array to get xls contents
		for(int i=1;i<retObjArr.length;i++){
			for(int n=0;n<retObjArr[i].length;n++){			
				//Store cell data and parent in local variable
				String cellData = String.valueOf(retObjArr[i][n]);
				String cellParent = String.valueOf(retObjArr[0][n]);
				
				
				
				//Loop though urls and run test
				if(n == 0){
					url = String.valueOf(retObjArr[i][n]);
					selenium.open(url);
					/*selenium.waitForPageToLoad("1000000");*/
					
					selenium.windowMaximize();
					selenium.windowFocus();
					
					
					//error logging
					sb.append("<div><div onClick=\"toggle('"+i+"')\">" + url +"</div>\n");
					sb.append("<div id=\"error"+i+"\" class=\"sub\">\n");
				}

				//return user to URL
				if(String.valueOf(retObjArr[0][n]).contains("*returnToURL*") && !cellData.isEmpty()){
					try{
						selenium.open(String.valueOf(url));
						/*selenium.waitForPageToLoad("100000");
						selenium.refresh();
						selenium.waitForPageToLoad("10000");*/
					} catch(Exception e){
						sb.append("<span class=\"select\">_@@@ RETURN URL @@@_</span> " + cellParent.substring(7) + ":" + cellData + "\n" + "<br />");
					}
				}
				
				
				//return user to URL
				if(String.valueOf(retObjArr[0][n]).contains("*waitForPage*") && !cellData.isEmpty()){
					try{
						selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span class=\"select\">_@@@ ERROR WAITING FOR PAGE @@@_</span> \n" + "<br />");
					}
				}
				
				
				//fill in input if it exists
				if(String.valueOf(retObjArr[0][n]).contains("*input*") && !cellData.isEmpty()){
					try{
						selenium.type(String.valueOf(retObjArr[0][n]).substring(7), String.valueOf(retObjArr[i][n]));
					} catch(Exception e){
						sb.append("<span class=\"select\">_@@@ BAD INPUT @@@_</span> " + cellParent.substring(7) + ":" + cellData + "\n" + "<br />");
					}
				}
				
				
				//scroll page to the bottom
				if(cellParent.contains("*scrollBottom*") && !cellData.isEmpty()){
					try{
						selenium.getEval("window.scrollTo(0,1000000)"); 
					} catch(Exception e){
						sb.append("<span>_@@@ BAD SCROLL TO BOTTOM @@@_</span> " + cellData + "\n" + "<br />");
					}
				}
				
				
				
				
				//change dropdown if it exists
				if(cellParent.contains("*select*") && !cellData.isEmpty()){
					try{
						selenium.select(cellParent.substring(8), cellData);
					} catch(Exception e){
						sb.append("<span>_@@@ BAD SELECT @@@_</span> " + cellParent.substring(8) + ":" + cellData + "\n" + "<br />");
					}
				}
				
				
				
				//click or unclick checkbox
				if(cellParent.contains("*checkBox*") && !cellData.isEmpty()){
					try{
						try{ selenium.click("//input[@id='"+cellParent.substring(10)+"' and @value='"+cellData+"']"); } catch(Exception e){}
						try{ selenium.click("//input[@name='"+cellParent.substring(10)+"' and @value='"+cellData+"']"); } catch(Exception e){}
						
					} catch(Exception e){
						sb.append("<span>_@@@ BAD CHECKBOX @@@_</span> " + cellParent.substring(10) + ":" + cellData + "\n" + "<br />");
					}
				}
				
				
	
				//wait for page redirect or something along those lines
				if(cellParent.contains("*waitForPage*") && !cellData.isEmpty()){
					selenium.waitForPageToLoad("1000000");
				}
				
				
				
				
				//select a radio button
				if(cellParent.contains("*radioButton*") && !cellData.isEmpty()){
					try{
						selenium.click("//input[@name='"+cellParent.substring(13)+"' and @value='"+cellData+"']");
					} catch(Exception e){
						sb.append("<span class=\"radio\">_@@@ BAD RADIO BUTTON @@@_</span> " + cellParent.substring(13) + ":" + cellData + "\n" + "<br />");
					}
				}
				
			
				
				//click on coordinates
				//parent 	- 	*click*
				//cellData 	- 	x,y
				if(cellParent.contains("*click*") && !cellData.isEmpty()){
					try{
						r.delay(2000);
						cellData = cellData.replaceAll("\\s+", "");
						r.mouseMove(Integer.parseInt(cellData.substring(0,cellData.indexOf(","))), Integer.parseInt(cellData.substring(cellData.indexOf(",")+1, cellData.length())));
						Thread.sleep(2000);
						r.mousePress(InputEvent.BUTTON1_MASK);
						r.mouseRelease(InputEvent.BUTTON1_MASK);
					} catch(Exception e){
						sb.append("<span>_@@@ BAD CLICK @@@_</span> " + cellData + "\n" + "<br />");
					}
				}
				
				
				
				//clicked on allows you to click on an object using ID tag
				//parent -	*clickOn*[inputID]
				//cell	 -	x || value
				if(cellParent.contains("*clickOn*") && !cellData.isEmpty()){
					selenium.click("id="+cellParent.substring(9));
					if(cellData.toLowerCase() != "x"){
						for(int z=0;z<cellData.trim().length();z++){
							int[] letters = typeLetter(cellData.charAt(z));
							for(int x=0;x<letters.length;x++){
								if(letters[x] != -1){
									r.keyPress(letters[x]);
									r.keyRelease(letters[x]);
								}
							}
						}
					}
				}
				
				//clicked on allows you to click on an object using ID tag
				//parent -	*clickOn*[inputID]
				//cell	 -	x || value
				if(cellParent.contains("*clicknOn*") && !cellData.isEmpty()){
					selenium.click("name="+cellParent.substring(10));
					if(cellData.toLowerCase() != "x"){
						for(int z=0;z<cellData.trim().length();z++){
							int[] letters = typeLetter(cellData.charAt(z));
							for(int x=0;x<letters.length;x++){
								if(letters[x] != -1){
									r.keyPress(letters[x]);
									r.keyRelease(letters[x]);
								}
							}
						}
					}
				}
		
				//use the robot to type
				if(cellParent.contains("*type*") && !cellData.isEmpty()){
					try{
						for(int z=0;z<cellData.trim().length();z++){
							int[] letters = typeLetter(cellData.charAt(z));
							for(int x=0;x<letters.length;x++){
								if(letters[x] != -1){
									r.keyPress(letters[x]);
									r.keyRelease(letters[x]);
								}
							}
						}
					} catch(Exception e){
						sb.append("<span>_@@@ BAD TYPE @@@_</span> " + cellData + "\n" + "<br />");
					}
				}				
				
				
				
				//click button if it exists and wait for next page
				if(cellParent.contains("*btnImage*") && !cellData.isEmpty()){
					try{
						selenium.click("//input[@type='image']");
						//selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span>_@@@ BAD IMAGE BUTTON CLICK @@@_</span>" + "\n<br />");
					}
				} else if(cellParent.contains("*btnSubmit*") && !cellData.isEmpty()){
					try{
						selenium.click("//input[@type='submit']");
						//selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span>_@@@ BAD SUBMIT BUTTON CLICK @@@_</span>" + "\n<br />");
					}
				} else if(cellParent.contains("*btnType*") && !cellData.isEmpty()){
					try{
						selenium.click("//input[@type='button']");
						//selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span>_@@@ BAD SUBMIT BUTTON CLICK @@@_</span>" + "\n<br />");
					}
				} else if(cellParent.contains("*btnName*") && !cellData.isEmpty()){
					try{
						selenium.click("//input[@id='"+cellData+"']");
						Thread.sleep(2000);
						//selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span>_@@@ BAD BTN NAME BUTTON CLICK @@@_</span>" + "\n<br />");
					}
				} else if(cellParent.contains("*btnClick*") && !cellData.isEmpty()){
					try{
						r.delay(2000);
						cellData = cellData.replaceAll("\\s+", "");
						r.mouseMove(Integer.parseInt(cellData.substring(0,cellData.indexOf(","))), Integer.parseInt(cellData.substring(cellData.indexOf(",")+1, cellData.length())));
						Thread.sleep(2000);
						r.mousePress(InputEvent.BUTTON1_MASK);
						r.mouseRelease(InputEvent.BUTTON1_MASK);
						selenium.waitForPageToLoad("1000000");
					} catch(Exception e){
						sb.append("<span>_@@@ BAD BTN BUTTON CLICK @@@_</span>\n<br />");
					}
				}
				
				
				
				//look to see if text is present
				if(cellParent.contains("*isTextPresent*") && !cellData.isEmpty()){
					try{
						if(!selenium.isTextPresent(cellData)){
							sb.append("<span class=\"noText\">_@@@ TEXT DOESN'T EXIST: @@@_</span> :"+cellData+"\n" + "<br />");
						}
					} catch(Exception e){
						sb.append("<span class=\"noText\">_@@@ BAD isTextPresent @@@_</span> :"+cellData+"\n" + "<br />");
					}
				}
				
				
				//look to see if text is not present
			    if(cellParent.contains("*isTextNotPresent*") && !cellData.isEmpty()){
			     try{
			      if(selenium.isTextPresent(cellData)){
			       sb.append("<span class=\"noText\">_@@@ TEXT EXIST: @@@_</span> :"+cellData+"\n" + "<br />");
			      }
			     } catch(Exception e){
			      sb.append("<span class=\"noText\">_@@@ BAD isTextPresent @@@_</span> :"+cellData+"\n" + "<br />");
			     }
			    }
				

				//Pause
				if(cellParent.contains("*wait*") && !cellData.isEmpty()){
					r.delay(3000);
					
				}
				
				
				//Press the tab key on keyboard
				if(cellParent.contains("*tabs*") && !cellData.isEmpty()){
					sb.append("<span>_@@@ TAB ISSUE @@@_</span>" + "\n<br />");
					try{
						//for(int z=0;z<Integer.parseInt(cellData);z++){
						r.keyPress(KeyEvent.VK_TAB);
						r.keyRelease(KeyEvent.VK_TAB);
						r.keyPress(KeyEvent.VK_TAB);
						r.keyRelease(KeyEvent.VK_TAB);
						r.keyPress(KeyEvent.VK_TAB);
						r.keyRelease(KeyEvent.VK_TAB);
							//selenium.keyPressNative(java.awt.event.KeyEvent.VK_TAB + "");
						//}
						
					} catch(Exception e){
						sb.append("<span>_@@@ TAB ISSUE @@@_</span>" + "\n<br />");
					}	
				}
				
				//Focus on element
				if(cellParent.contains("*focus*") && !cellData.isEmpty()){
					selenium.focus("//input[@id='"+cellData+"']") ;
					
				}
				
				
				//Press the enter key on keyboard
				if(cellParent.contains("*enter*") && !cellData.isEmpty()){
					try{
						r.keyPress(KeyEvent.VK_ENTER);
						r.keyRelease(KeyEvent.VK_ENTER);
					} catch(Exception e){
						sb.append("<span>_@@@ ENTER ISSUE @@@_</span>" + "\n<br />");
					}	
				}
				
				
				//See if input values exist
				//See links href, alt tags
				//take a screenshot if it exists
				if(cellParent.contains("*screenShot*") && !cellData.isEmpty()){
					String path = cellData;
					try{
						//See if image filename is specified
						if(cellData.indexOf(';') == -1){
							//No filename specified
							
							//add trailing slash to path
							if(path.substring(path.length()-1) != "/" && path.substring(path.length()-1) != "\\"){
								path = path + "/";
							}
							
							//Create screenshot
							selenium.captureEntirePageScreenshot(path+System.currentTimeMillis()+".png", "");
						} else {
							//Filename specified so lets use that
							String[] tmp = cellData.split(";");
							path = tmp[0];
							
							//add trailing slash to path
							if(path.substring(path.length()-1) != "/" && path.substring(path.length()-1) != "\\"){
								path = path + "/";
							}

							//Create screenshot
							selenium.captureEntirePageScreenshot(path+tmp[1]+".png", "");
						}
					} catch(Exception e){
						sb.append("<span>_@@@ BAD SCREENSHOT @@@_</span>" + "\n<br />");
					}
				}
				
				//Close error logging
				if(n==retObjArr[i].length-1){
					sb.append("</div></div>");
				}
				
				//Write log if anything went wrong
				try{
					// Create file 
					FileWriter fstream = new FileWriter(logPath);
					BufferedWriter out = new BufferedWriter(fstream);
					out.write(sb.toString());
					//Close the output stream
					out.close();
				}catch (Exception e){//Catch exception if any
					System.err.println("Error: " + e.getMessage());
				}
				
				
			}
			
			
		}
  

			  
	    sb = null;
	    

	    Mailmanx newmail=new Mailmanx();
	    try {
	    	newmail.Sendmail("the body", "NYTHD Selenium Output");
	    	
	    } catch (MessagingException e) {
	    	// TODO Auto-generated catch block
	    	e.printStackTrace();
	    }

	   

	    

      }

	@AfterClass
    public void tearDown(){
        selenium.close();
        selenium.stop();
    } 

	
	public String[][] getTableArray(String xlFilePath, String sheetName) throws Exception{
		System.out.println(xlFilePath);
		String[][] tabArray=null;
        Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
        Sheet sheet = workbook.getSheet(sheetName); 
        int startRow = 0,startCol = 0, endRow, endCol, ci, cj;

        Cell tableEnd= sheet.findCell("tableEND", startCol+1,startRow+1, 1000, 1000,  false);
        endRow=tableEnd.getRow();
        endCol=tableEnd.getColumn();
        
        System.out.println("~~~~startRow="+startRow+", endRow="+endRow+", " + "startCol="+startCol+", endCol="+endCol);
        tabArray=new String[endRow][endCol];
        
        ci=0;
        for(int i=startRow;i<endRow;i++,ci++){
            cj=0;
            for(int j=startCol;j<endCol;j++,cj++){
            	System.out.println("~~~~ci:" + ci + ", cj:" + cj + " " + sheet.getCell(j,i).getContents());
            	tabArray[ci][cj]=sheet.getCell(j,i).getContents();
            }
        }
        return(tabArray);
    }
	
	
	private int[] typeLetter(char character){
		int[] j = new int[2];
		j[0] = -1;
		j[1] = -1;
        switch (character) {
	        case 'a': j[0] = KeyEvent.VK_A; return j;
	        case 'b': j[0] = KeyEvent.VK_B; return j;
	        case 'c': j[0] = KeyEvent.VK_C; return j;
	        case 'd': j[0] = KeyEvent.VK_D; return j;
	        case 'e': j[0] = KeyEvent.VK_E; return j;
	        case 'f': j[0] = KeyEvent.VK_F; return j;
	        case 'g': j[0] = KeyEvent.VK_G; return j;
	        case 'h': j[0] = KeyEvent.VK_H; return j;
	        case 'i': j[0] = KeyEvent.VK_I; return j;
	        case 'j': j[0] = KeyEvent.VK_J; return j;
	        case 'k': j[0] = KeyEvent.VK_K; return j;
	        case 'l': j[0] = KeyEvent.VK_L; return j;
	        case 'm': j[0] = KeyEvent.VK_M; return j;
	        case 'n': j[0] = KeyEvent.VK_N; return j;
	        case 'o': j[0] = KeyEvent.VK_O; return j;
	        case 'p': j[0] = KeyEvent.VK_P; return j;
	        case 'q': j[0] = KeyEvent.VK_Q; return j;
	        case 'r': j[0] = KeyEvent.VK_R; return j;
	        case 's': j[0] = KeyEvent.VK_S; return j;
	        case 't': j[0] = KeyEvent.VK_T; return j;
	        case 'u': j[0] = KeyEvent.VK_U; return j;
	        case 'v': j[0] = KeyEvent.VK_V; return j;
	        case 'w': j[0] = KeyEvent.VK_W; return j;
	        case 'x': j[0] = KeyEvent.VK_X; return j;
	        case 'y': j[0] = KeyEvent.VK_Y; return j;
	        case 'z': j[0] = KeyEvent.VK_Z; return j;
	        case 'A': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_A; return j;
	        case 'B': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_B; return j;
	        case 'C': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_C; return j;
	        case 'D': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_D; return j;
	        case 'E': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_E; return j;
	        case 'F': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_F; return j;
	        case 'G': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_G; return j;
	        case 'H': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_H; return j;
	        case 'I': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_I; return j;
	        case 'J': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_J; return j;
	        case 'K': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_K; return j;
	        case 'L': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_L; return j;
	        case 'M': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_M; return j;
	        case 'N': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_N; return j;
	        case 'O': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_O; return j;
	        case 'P': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_P; return j;
	        case 'Q': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_Q; return j;
	        case 'R': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_R; return j;
	        case 'S': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_S; return j;
	        case 'T': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_T; return j;
	        case 'U': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_U; return j;
	        case 'V': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_V; return j;
	        case 'W': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_W; return j;
	        case 'X': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_X; return j;
	        case 'Y': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_Y; return j;
	        case 'Z': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_Z; return j;
	        case '`': j[0] = KeyEvent.VK_BACK_QUOTE; return j;
	        case '0': j[0] = KeyEvent.VK_0; return j;
	        case '1': j[0] = KeyEvent.VK_1; return j;
	        case '2': j[0] = KeyEvent.VK_2; return j;
	        case '3': j[0] = KeyEvent.VK_3; return j;
	        case '4': j[0] = KeyEvent.VK_4; return j;
	        case '5': j[0] = KeyEvent.VK_5; return j;
	        case '6': j[0] = KeyEvent.VK_6; return j;
	        case '7': j[0] = KeyEvent.VK_7; return j;
	        case '8': j[0] = KeyEvent.VK_8; return j;
	        case '9': j[0] = KeyEvent.VK_9; return j;
	        case '-': j[0] = KeyEvent.VK_MINUS; return j;
	        case '=': j[0] = KeyEvent.VK_EQUALS; return j;
	        case '~': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_BACK_QUOTE; return j;
	        case '!': j[0] = KeyEvent.VK_EXCLAMATION_MARK; return j;
	        case '@': j[0] = KeyEvent.VK_AT; return j;
	        case '#': j[0] = KeyEvent.VK_NUMBER_SIGN; return j;
	        case '$': j[0] = KeyEvent.VK_DOLLAR; return j;
	        case '%': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_5; return j;
	        case '^': j[0] = KeyEvent.VK_CIRCUMFLEX; return j;
	        case '&': j[0] = KeyEvent.VK_AMPERSAND; return j;
	        case '*': j[0] = KeyEvent.VK_ASTERISK; return j;
	        case '(': j[0] = KeyEvent.VK_LEFT_PARENTHESIS; return j;
	        case ')': j[0] = KeyEvent.VK_RIGHT_PARENTHESIS; return j;
	        case '_': j[0] = KeyEvent.VK_UNDERSCORE; return j;
	        case '+': j[0] = KeyEvent.VK_PLUS; return j;
	        case '\t': j[0] = KeyEvent.VK_TAB; return j;
	        case '\n': j[0] = KeyEvent.VK_ENTER; return j;
	        case '[': j[0] = KeyEvent.VK_OPEN_BRACKET; return j;
	        case ']': j[0] = KeyEvent.VK_CLOSE_BRACKET; return j;
	        case '\\': j[0] = KeyEvent.VK_BACK_SLASH; return j;
	        case '{': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_OPEN_BRACKET; return j;
	        case '}': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_CLOSE_BRACKET; return j;
	        case '|': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_BACK_SLASH; return j;
	        case ';': j[0] = KeyEvent.VK_SEMICOLON; return j;
	        case ':': j[0] = KeyEvent.VK_COLON; return j;
	        case '\'': j[0] = KeyEvent.VK_QUOTE; return j;
	        case '"': j[0] = KeyEvent.VK_QUOTEDBL; return j;
	        case ',': j[0] = KeyEvent.VK_COMMA; return j;
	        case '<': j[0] = KeyEvent.VK_LESS; return j;
	        case '.': j[0] = KeyEvent.VK_PERIOD; return j;
	        case '>': j[0] = KeyEvent.VK_GREATER; return j;
	        case '/': j[0] = KeyEvent.VK_SLASH; return j;
	        case '?': j[0] = KeyEvent.VK_SHIFT; j[1] = KeyEvent.VK_SLASH; return j;
	        case ' ': j[0] = KeyEvent.VK_SPACE; return j;
	        default:
	                throw new IllegalArgumentException("Cannot type character " + character);
        }	
	}
}
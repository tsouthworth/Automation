
public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new regularTest();
		

	}

}
